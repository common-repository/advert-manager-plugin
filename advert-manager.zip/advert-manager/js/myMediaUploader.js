jQuery(document).ready(function() {

	var formfield;

	/* user clicks button on custom field, runs below code that opens new window */
	jQuery('#upload_image_button').click(function() {
		formfield = jQuery('#upload_image').attr('name');
		tb_show('','http://localhost/houseofdecor/wp-content/plugins/advert-manager/image-upload.php?TB_iframe=true');
		return false;
	});

	// user inserts file into post. only run custom if user started process using the above process
	// window.send_to_editor(html) is how wp would normally handle the received data
});

